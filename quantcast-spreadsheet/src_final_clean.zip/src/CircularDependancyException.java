
public class CircularDependancyException extends Exception {

	public CircularDependancyException(String string) {
		super(string);
	}
}
