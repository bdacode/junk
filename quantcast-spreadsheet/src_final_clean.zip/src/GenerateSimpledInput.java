
public class GenerateSimpledInput {
	
	public static void main(String[] args) {
		int n = 10000;
		int m = 1;

		System.out.println(n+" "+m);
		System.out.println(1);
		for (int i=1;i<n;i++) {
			System.out.println("A"+(i)+" 1 +");
		}
	}
	
}
